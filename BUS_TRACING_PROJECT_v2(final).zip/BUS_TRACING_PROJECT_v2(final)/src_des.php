<!Doctype html>
<html>
    <head>
        
     <title>Source_Destination</title>
	 
<style type="text/css">	 


body{
	
	background-color:#DC143C;;
}
	 
	 
h1{
	
  font-size:3em;
  color:white;
  margin:0;
  padding:0;
  text-align:center;
  font-family:'ALGERIAN';
  position:absolute;
  top:10%;
  left:35%

}

form{
	
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: black;
  background-color:purple;
  border:none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
  font-family:'ALGERIAN';
  position:absolute;
  top:40%;
  left:9%
}
h2{
	
  font-size:2em;
  color:white;
  margin:0;
  padding:0;
  text-align:center;
  font-family:'ALGERIAN';
  position:absolute;
  top:34%;
  left:10%

}
h3{
	
  font-size:2em;
  color:white;
  margin:0;
  padding:0;
  text-align:center;
  font-family:'ALGERIAN';
  position:absolute;
  top:34%;
  left:23%

}







</style>
	 
	 
    </head>
    <body>
	    <h1>Wellcome To Search Page</h1>
		
	    <h2>SOURCE:  </h2>
		<h3>DESTINATION:</h3>
		<form method="post" action="traffic.html">
            <input type="text" name="src">
			<input type="text" name="dest">
            <input id="go" type="submit"  value="GO">
        </form>
        
    </body>
</html>
