<?php
  
      //------------- path array------------------------
      $src="";
      $dest="";
	  $path_no = "";


      if(isset($_GET['src']) && isset($_GET['dest']) && isset($_GET['path_no']))
      {
            $src=$_GET['src'];
            $dest=$_GET['dest'];
			$path_no = $_GET['path_no'];
			
			//echo $src . " " . $dest. " ". $path_no. "\n";
      }
	  
	  //echo $src . "jhgkj" . $dest. " ". $path_no. "\n";


//-------------------------bfs start--------------------------------------------------
      $graph = array(
          array(1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
          array(0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0),
          array(0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0),
          array(0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0),
          array(0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0),
          array(0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0),
          array(0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0),
          array(0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0),
          array(0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0),
          array(0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0),
          array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
      );

      $username = "root";
      $pass = "";
      $serveraddr = "localhost";
      $dbname = "ubus";

      try {
          $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $pass);
          $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          $stmt = "Select * from routes ";
          $pdostmt = $conn->prepare($stmt);
          $pdostmt->execute();
          $res = $pdostmt->fetchAll(PDO::FETCH_NUM);


          for ($it = 0; $it < count($res); $it++) {

              for ($j = 0; $j < count($res); $j++) {

                  $s = $res[$it][1];
                  $d = $res[$it][4];

                  if ($graph[$s][$d] == 0) {
                      $graph[$s][$d] = 1;
                      $graph[$s][$d] = 1;
                  }
              }
          }
      } catch (PDOException $ex) {
          echo "<script>window.alert('database not connected');</script>";
      }


      function breadthFirst($graph, $start, $dest, $count) {
          ///to count the total no of paths found
        $counter = 0;

          ///declaring
          $parents = array();
          $queue = array();
          
        ///initializing
          foreach ($graph as $key => $vertex) {
              $parents[$key] = -1;  //// -1 means nil
          }

          ///starting from the src
          array_push($queue, $start);
          $parents[$start] = -2; //// -2 means $start is a root node

          while (count($queue)) {
              //var_dump($queue); echo "<br/>";
             
              $t = array_shift($queue);
              foreach ($graph[$t] as $key => $vertex) {
        
                if($vertex == 1 && $key==$dest){  ///meaning it is possible to reach from $t to $dest
                  ////printing the path
                  $parents[$key]=$t;
                  $path_arr = array();
				  
				  if($path_arr == $counter) array_push($path_arr, $dest);

                  $tmp = $dest;
                  while ($parents[$tmp] != -2) {
                    $tmp = $parents[$tmp];
                    if($path_arr == $counter) array_push($path_arr, $tmp);
                  }

				  
                  ////showing the whole path
                  /*echo "path no: " . $counter . "<br/>";
                  for ($i = count($path_arr) - 1; $i >= 0; $i--) {
                    echo $path_arr[$i] . " --> ";
                  }
                  echo "<br/>----------------------------<br/>";*/

                  

//-----------------bfs end for now-------------------------------------------

      $locations=array();

      $uname="root"; //Username of a database.
      $pass="";  //Password of database.
      $servername="localhost"; //Database servername.
      $dbname="ubus";  // Your database name.

      $db=new mysqli($servername,$uname,$pass,$dbname); // This line is connecting to database using mysqli method.


      for ($i = 0; $i < count($path_arr); $i++){

        $query =  $db->query("SELECT * FROM routes Where source = '$path_arr[$i]' or destination = '$path_arr[$i]'"); //Retriving the value database.


        while( $row = $query->fetch_assoc() )
        { 
          $name = $row['source']; 
          $longitude = $row['source_long'];                              
          $latitude = $row['source_lat'];
          $link=$row['destination'];
                      /* Each row is added as a new array */
          $locations[]=array( 'source'=>$name, 'source_lat'=>$latitude, 'source_long'=>$longitude , 'destination'=>$link );

        }

      }


//-----------------bfs rest of the code--------------------

///increasing the counts
                  $counter = $counter + 1;
				  if($counter > $path_no) break; 
                  if ($counter == $count) {
                    break;
                  }
                }
                else if ($vertex == 1 && $parents[$t] != $key && $key != $start && $key != $t) {
                  $parents[$key] = $t;
                  ///now inserting into the queue
                  array_push($queue, $key);
                }

              }
        }
      }

      breadthFirst($graph, $dest, $src, 5, $path_no);

//------------------bfs end---------------------------


      

?>


<html>
<body>
    <head>
        <title>Google Map Using PHP and MySql.</title>
        <style>
        #map{
            height:100%;
            weight:100px;
        }
        </style>
    
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDrMTfBa9NXyO3izpTE1hrR96YGxmMin4g"></script> 
    <script type="text/javascript">
    var map;
    var Markers = {};
    var infowindow;
    var locations = [
        <?php for($i=0;$i<sizeof($locations);$i++){ $j=$i+1;?>
        [
            'AMC Service',
            '<p>.....<a href="<?php echo $locations[0]['destination'];?>"></a></p>',
            <?php echo $locations[$i]['source_lat'];?>,
            <?php echo $locations[$i]['source_long'];?>,
            0
        ]<?php if($j!=sizeof($locations))echo ","; }?>
    ];
	
	  //Loop through markers
      // for(var i = 0;i < locations.length;i++){
       // Add marker
        // addMarker(locations[$i]['lat']);
		// addMarker(locations[$i]['lng']);
      // }
	
    var origin = new google.maps.LatLng(locations[0][2], locations[0][3]);
    function initialize() {
      var mapOptions = {
        zoom: 12,
        center: origin
      };
      map = new google.maps.Map(document.getElementById('map'), mapOptions);
        infowindow = new google.maps.InfoWindow();
        for(i=0; i<locations.length; i++) {
            var position = new google.maps.LatLng(locations[i][2], locations[i][3]);
            var marker = new google.maps.Marker({
                position: position,
                map: map,
            });
            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                return function() {
                    infowindow.setContent(locations[i][1]);
                    infowindow.setOptions({maxWidth: 200});
                    infowindow.open(map, marker);
                }
            }) (marker, i));
            Markers[locations[i][4]] = marker;
        }
		
		for (i = 0; i < locations.length - 1; i++){
			var position1 = new google.maps.LatLng(locations[i][2], locations[i][3]);
			var position2 = new google.maps.LatLng(locations[i+1][2], locations[i+1][3]);
			var flightPath = new google.maps.Polyline({
				path: [position1, position2],
				strokeColor: "#0000FF",
				strokeOpasity: 0.8,
				strokeWeight: 2
				
			});
			flightPath.setMap(map);
		}

		
        locate(0);
		//add traffic layer
		var trafficLayer = new google.maps.TrafficLayer();
        trafficLayer.setMap(map);
    }
    function locate(marker_id) {
        var myMarker = Markers[marker_id];
        var markerPosition = myMarker.getPosition();
        map.setCenter(markerPosition);
        google.maps.event.trigger(myMarker, 'click');
    }
    google.maps.event.addDomListener(window, 'load', initialize);
    </script>
</head>

<div id="map"></div>

</body>
</html>