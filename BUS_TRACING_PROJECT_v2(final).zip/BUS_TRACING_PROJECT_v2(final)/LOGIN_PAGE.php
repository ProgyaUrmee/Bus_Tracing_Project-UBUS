<!DOCTYPE html>
<html>
<head>
<style> 
body
{
background:#ffccff;
}


#form{ width:400px;
      margin:auto;
      background:#cc66cc;
      font-size:50px;
      font-family:verdana;
      text-align:center;
      position:absolute;
      top:30%;
      left:35%


}

h1{
  font-size:3em;
  margin:0;
  padding:0;
  text-align:center;
  font-family:'arial';
  position:absolute;
  top:10%;
  left:30%;
}
#reviw{
	
	border:1px solid;
	width:300px;
	height:100px;
	margin-top:500px;
	margin-right:500px;
	margin-bottom:300px;
	overflow:scroll;
}
h2{
	text-align:left;
	font-family:'arial';
    position:absolute;
    top:65%;
    left:1%;

	
}

</style>
</head>
<body>



<h1><b>WellCome To Login Page</b></h1>
<h2>Comment:</h2>
<div id="reviw">

</div>

<div id="form">
<br>Username:</br>
<input type="text" name="username"/>
<br>Password:</br>
<input type="password" name="password"/>
<br>PhoneNum:</br>
 <a href="https://www.youtube.com/">
  <input type="button" value="Clcik"/>
 </a>
 </div>


</body>
</html>
