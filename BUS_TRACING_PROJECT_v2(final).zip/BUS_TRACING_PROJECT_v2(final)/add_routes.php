<!DOCTYPE html>
<html>
<head>
<title>insert Data</title>
<link href="add_routes.css" rel="stylesheet">
</head>
<body>
<div class="maindiv">
<!--HTML Form -->
<div class="form_div">
<div class="title">
<h2>Insert ROUTES Data Into Database</h2>
</div>
<form action="add_routes.php" method="post">
<!-- Method can be set as POST for hiding values in URL-->
<h2>UBUS_routes</h2>
<label>NEW LOCATION NAME:</label>
<input class="input" name="location" type="text" value="">
<label>SOURCE:</label>
<input class="input" name="source" type="text" value="">
<label>SOURCE_LAT:</label>
<input class="input" name="source_lat" type="text" value="">
<label>SOURCE_LONG:</label>
<input class="input" name="source_long" type="text" value="">
<label>DESTINATION:</label>
<input class="input" name="destination" type="text" value="">
<label>DEST_LAT:</label>
<input class="input" name="dest_lat" type="text" value="">
<label>DEST_LONG:</label>
<input class="input" name="dest_long" type="text" value=""><br>

<input class="submit" name="submit" type="submit" value="Insert">
</form>
</div>
</div>
</body>
</html>

<?php
$connection = mysqli_connect("localhost","root","" ,"ubus" ); // Establishing Connection with Server
//$db = mysqli_select_db("colleges", $connection); // Selecting Database from Server
if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$location = $_POST['location'];
$source = $_POST['source'];
$source_lat = $_POST['source_lat'];
$source_long = $_POST['source_long'];
$destination = $_POST['destination'];
$dest_lat = $_POST['dest_lat'];
$dest_long = $_POST['dest_long'];
if($source !=''&&$source_lat !=''&&$source_long !=''&&$destination !=''&&$dest_lat!=''&&$dest_long !=''&&$location !=''){
//Insert Query of SQL
$query = mysqli_query($connection, "insert into routes(source, source_lat, source_long, destination, dest_lat, dest_long) values ('$source', '$source_lat', '$source_long', '$destination','$dest_lat', '$dest_long')");
$query = mysqli_query($connection, "insert into loc(name) values ('$location')");
echo "<br/><br/><span>Data Inserted successfully...!!</span>";
}
else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}
}
mysqli_close($connection); // Closing Connection with Server
?>